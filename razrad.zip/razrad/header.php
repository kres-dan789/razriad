<?php include('db.php'); ?>
<header>
    <nav class="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-brand">Home</a>
            <ul class="navbar-menu">
                <li><a href="theory.php">Theory</a></li>
                <li><a href="tests.php">Tests</a></li>
                <li><a href="add_data.php">Add Data</a></li>
            </ul>
        </div>
    </nav>
</header>
