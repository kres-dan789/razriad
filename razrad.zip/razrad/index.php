<?php include('db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('header.php'); ?>
<div class="container">
    <h1>Welcome to the Learning Platform</h1>
    <p>This platform allows you to learn and test your knowledge on various topics.</p>
</div>
</body>
</html>
